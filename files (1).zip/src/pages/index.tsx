import Navbar from '../components/Navbar';

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <Navbar />
      <main className="flex flex-col items-center justify-center py-24">
        <h1 className="text-5xl font-extrabold mb-6 text-blue-700">
          FlowMind
        </h1>
        <p className="text-xl text-gray-700 mb-8 text-center max-w-xl">
          Build, automate, and unleash your wildest ideas. Drag, drop, and let AI do the rest.
        </p>
        <a
          href="/builder"
          className="px-8 py-4 bg-blue-700 text-white rounded-lg font-bold shadow-lg hover:bg-blue-800 transition"
        >
          Launch Builder
        </a>
      </main>
    </div>
  );
}