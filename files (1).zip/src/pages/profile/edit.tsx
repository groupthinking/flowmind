import { useSupabaseAuth } from '../../utils/useSupabaseAuth';
import { updateUserProfile } from '../../utils/socialApi';
import { useState } from 'react';

export default function EditProfile() {
  const { user } = useSupabaseAuth();
  const [displayName, setDisplayName] = useState('');
  const [avatarUrl, setAvatarUrl] = useState('');

  async function handleSave(e) {
    e.preventDefault();
    await updateUserProfile(user, { display_name: displayName, avatar_url: avatarUrl });
    alert('Profile updated!');
  }

  return (
    <form className="max-w-md mx-auto py-8" onSubmit={handleSave}>
      <h1 className="text-2xl font-bold mb-4">Edit Profile</h1>
      <label>Display Name</label>
      <input className="border w-full px-3 py-2 mb-4" value={displayName} onChange={e=>setDisplayName(e.target.value)} />
      <label>Avatar URL</label>
      <input className="border w-full px-3 py-2 mb-4" value={avatarUrl} onChange={e=>setAvatarUrl(e.target.value)} />
      <button className="bg-blue-700 text-white px-4 py-2 rounded" type="submit">Save</button>
    </form>
  );
}